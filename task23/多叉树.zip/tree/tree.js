 var dom = document.querySelector("#tree")
 var ss = [],
     timer = null,
     isFirst = false;
 /* 深度*/
 function traverseDF(doms) {
     for (var i = 0, length = doms.children.length; i < length; i++) {
         if (doms.children[i].tagName == "DIV") {
             traverseDF(doms.children[i]);
             ss.push(doms.children[i])
         }

         if (isFirst == false) {
             setTimeout(function() {
                 ss.push(doms)
             }, 0)
             isFirst = true;
         }
     }
 }

 /*广度*/
 var z = 0

 function traverseBF(node) {;
     if (node) {
         ss.push(node);
         if (z > 0) {
             traverseBF(node.nextElementSibling);
         }
         node = ss[z++];
         if (node.firstElementChild) {

             if (node.firstElementChild.tagName == "SPAN") {
                 traverseBF(node.firstElementChild.nextElementSibling);
             } else {
                 traverseBF(node.firstElementChild);
             }
         }
     }
 }

 function changeColor(arr) {
     var i = 0;
     timer = setInterval(function() {
         if (i <= arr.length) {
             if (i < arr.length) {
                 arr[i].setAttribute("class", "blue")
             }
             if (i > 0) {
                 arr[i - 1].setAttribute("class", "")
             }
         } else {
             clearInterval(timer)
         }
         i++;
     }, 500)
 }

 function resetColor() {
     isFirst = false;
     clearInterval(timer);
     for (var i = 0; i < ss.length; i++) {
         ss[i].setAttribute("class", "")
     }
     ss = [];
 }

 function searchText(arr, str) {
     // for (var i = 0; i < arr.length; i++) {
     //   if (arr[i].children) {
     //     for (var j = 0; j < arr[i].children.length; j++) {
     //       if (arr[i].children[j].tagName="SPAN") {

     //         if(arr[i].children[j].innerHTML==str){
     //            console.log(arr[i].children[j].innerHTML)
     //           arr[i].setAttribute("class","red")
     //         }
     //       }

     //     }
     //   }
     // }
     var i = 0;
     timer = setInterval(function() {
         if (i < arr.length) {
             arr[i].setAttribute("class", "blue");
             if (arr[i].children) {
                 for (var j = 0; j < arr[i].children.length; j++) {
                     if (arr[i].children[j].tagName = "SPAN") {

                         if (arr[i].children[j].innerHTML == str) {
                             console.log(arr[i].children[j].innerHTML)
                             arr[i].setAttribute("class", "red")
                             clearInterval(timer)
                         }
                     }
                 }
             }
             if (i > 0) {
                 arr[i - 1].setAttribute("class", "")
             }
         } else {
             clearInterval(timer)
         }
         i++;
     }, 500)

 }

 document.getElementById("deep").onclick = function() {
     resetColor(ss)
     traverseDF(dom)
     changeColor(ss)


 }
 document.getElementById("qian").onclick = function() {
     resetColor(ss)
     traverseBF(dom)
     changeColor(ss)

 }
 console.log(document.getElementById("search"))
 document.getElementById("searchbtn").onclick = function() {
     var inpt = document.getElementById("search").value;
     resetColor(ss)
     traverseDF(dom)
     searchText(ss, inpt)

 }
